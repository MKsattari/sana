<!--##session userfunction##-->
<?php
// Global user functions
<!--##~SYSTEMFUNCTIONS.GetServerScript("Global","Page_Loading")##-->
<!--##~SYSTEMFUNCTIONS.GetServerScript("Global","Page_Rendering")##-->
<!--##~SYSTEMFUNCTIONS.GetServerScript("Global","Page_Unloaded")##-->
<!--##~SYSTEMFUNCTIONS.GetServerScript("Global","Global Code")##-->
?>
<!--##/session##-->
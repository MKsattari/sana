<?php
<!--##session report_html_function##-->
<!--##
	if (bPrinterFriendly) {
##-->

	// Export report to HTML
	function ExportReportHtml($html) {
		//global $gsExportFile;
		//header('Content-Type: text/html' . (EW_CHARSET <> '' ? ';charset=' . EW_CHARSET : ''));
		//header('Content-Disposition: attachment; filename=' . $gsExportFile . '.html');
		//echo $html;
	}

<!--##
	};
##-->
<!--##/session##-->
?>